function getBotResponse(input) {
   
    if (input == "GoodMoring") {
        return "Very GoodMoring";
    } else if (input == "GoodNoon") {
        return "Very GoodNoon";
    } else if (input == "GoodNight") {
        return "GoodNoon Bye";
    }
    else if(input == "Hello")
    {
        return "Hello there!";
    }
    else if (input == "goodbye")
    {
        return "Talk to you later!";
    }
    else if (input == "Help")
    {
        return "I can I help YOU";
    }
     else if (input == "YourName")
    {
        return "My Name is Alexa";
    }
    else if (input == "Hii") {
        return "Hello";
    }
     else
     {
        return "Try ask something else!";
    }
}