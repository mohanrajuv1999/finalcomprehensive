﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class ContactUs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSub_Click(object sender, EventArgs e)
    {
        
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["MyEShopingDB"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Insert into tblContactUs(UserName,EmailId,Subject,Description) Values('" +Us1.Text+ "','" + Em1.Text + "','" + Sub1.Text + "','" +Des1.Text + "')", con);
                cmd.ExecuteNonQuery();

                con.Close();
            Response.Write("<script> alert('Submit Sucess');  </script>");
            
            }
        

    }
}